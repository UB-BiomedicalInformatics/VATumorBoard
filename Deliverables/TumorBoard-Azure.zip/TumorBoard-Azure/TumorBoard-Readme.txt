1. Install Orthanc server from the exe file 'OrthancInstaller-Win64-18.5.2.exe' by double clicking and click next until Finish.
For reference: I have Downloaded Orthanc Server for windows:
https://www.orthanc-server.com/download-windows.php
2. Replace the Configuration file in 'Orthanc Server' folder installed in default location: 
C:\Program Files\Orthanc Server\Configuration\orthanc.json with the one that is enclosed ( for modifying "RemoteAccessAllowed" to true)
3. Set the firewall inbound and outbound rule to allow access of port '8042' which is the Orthanc PACS Server port.
4. Once the Orthanc Server is installed, Go to localhost:8042 and Upload Sample images for one patient from 'Images' folder by dragging and dropping and clicking on 'Upload' at the Top right corner of the Orthanc PACS Server homepage, then click on 'Start the upload'.
5. Once the images are uploaded, Patient Birth Date, ID and Sex would be displayed. Click on it.
6. Towards the right section of the next page, the Patient name along with Study information is displayed. Click on it.
7. Towards the right section of the next page, the Series name along with Series information is displayed. Click on it.
8. Click on Osimis Web Viewer and copy the URL displayed:
http://localhost:8042/osimis-viewer/app/index.html?series=aa1d6953-df75319a-689936be-acc31b61-a02c8732
9. Deploy 'TumorBoard.war' in Apache Tomcat.
10. Go to Apache Tomcat, deployed webapps folder and change the file 'imaging.html' in the path say:
C:\Program Files\Apache Software Foundation\Tomcat 7.0\webapps\TumorBoard\imaging.html with the URL above in step 8, replacing 'localhost' with 'uploaded server ip address' like:
http://128.205.2.59:8042/osimis-viewer/app/index.html?series=aa1d6953-df75319a-689936be-acc31b61-a02c8732
Replace the path in 2 places in the following 2 functions in imaging.html as shown below:

function viewer() {
	    $("#content").attr("src","http://128.205.2.59:8042/osimis-viewer/app/index.html?series=aa1d6953-df75319a-689936be-acc31b61-a02c8732");
	}
 function fullscreenviewer() {
	    window.open("http://128.205.2.59:8042/osimis-viewer/app/index.html?series=aa1d6953-df75319a-689936be-acc31b61-a02c8732");
	} 
11. Restart Tomcat and now run the URL:
http://128.205.2.59:8081/TumorBoard/home.html




